<?php

return [
    'Home' => 'الرئيسة',
    "Find Work" => "فرص عمل",
];