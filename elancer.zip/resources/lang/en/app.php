<?php

return [
    'Home' => 'Home',
    "Find Work" => "Find Work",
];