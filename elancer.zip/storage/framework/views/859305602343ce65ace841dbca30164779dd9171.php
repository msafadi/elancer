<?php echo e($slot); ?>

<?php /**PATH D:\www\elancer\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>