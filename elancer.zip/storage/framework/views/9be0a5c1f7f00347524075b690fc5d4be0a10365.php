<select name="country" class="selectpicker with-border" data-size="7" title="Select Job Type" data-live-search="true">
    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($code); ?>" <?php if($code == $selected): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH D:\www\elancer\resources\views/components/country-select.blade.php ENDPATH**/ ?>