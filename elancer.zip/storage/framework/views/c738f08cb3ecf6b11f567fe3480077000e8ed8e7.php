<?php echo e($slot); ?>

<?php /**PATH D:\www\elancer\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>