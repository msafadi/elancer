<!doctype html>
<html lang="<?php echo e(App::currentLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">

<head>

    <!-- Basic Page Needs
================================================== -->
    <title><?php echo e(config('app.name')); ?> | <?php echo e($title); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
================================================== -->
    <?php if( LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.rtl.css')); ?>">
    <?php else: ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/colors/blue.css')); ?>">

</head>

<body>

    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Header Container
================================================== -->
        <header id="header-container" class="fullwidth">

            <!-- Header -->
            <div id="header">
                <div class="container">

                    <!-- Left Side Content -->
                    <div class="left-side">

                        <!-- Logo -->
                        <div id="logo">
                            <a href="index.html"><img src="<?php echo e(asset('assets/front/images/logo.png')); ?>" alt=""></a>
                        </div>

                        <!-- Main Navigation -->
                        <nav id="navigation">
                            <ul id="responsive">

                                <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                                    <ul class="dropdown-nav">
                                        <li><a href="index.html">Home 1</a></li>
                                        <li><a href="index-2.html">Home 2</a></li>
                                        <li><a href="index-3.html">Home 3</a></li>
                                    </ul>
                                </li>

                                <li><a href="#"><?php echo e(trans('Find Work')); ?></a>
                                    <ul class="dropdown-nav">
                                        <li><a href="#"><?php echo app('translator')->get('Browse Jobs'); ?></a>
                                            <ul class="dropdown-nav">
                                                <li><a href="jobs-list-layout-full-page-map.html">Full Page List + Map</a></li>
                                                <li><a href="jobs-grid-layout-full-page-map.html">Full Page Grid + Map</a></li>
                                                <li><a href="jobs-grid-layout-full-page.html">Full Page Grid</a></li>
                                                <li><a href="jobs-list-layout-1.html">List Layout 1</a></li>
                                                <li><a href="jobs-list-layout-2.html">List Layout 2</a></li>
                                                <li><a href="jobs-grid-layout.html">Grid Layout</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#"><?php echo e(Lang::get('Browse Tasks')); ?></a>
                                            <ul class="dropdown-nav">
                                                <li><a href="tasks-list-layout-1.html">List Layout 1</a></li>
                                                <li><a href="tasks-list-layout-2.html">List Layout 2</a></li>
                                                <li><a href="tasks-grid-layout.html">Grid Layout</a></li>
                                                <li><a href="tasks-grid-layout-full-page.html">Full Page Grid</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="browse-companies.html">Browse Companies</a></li>
                                        <li><a href="single-job-page.html">Job Page</a></li>
                                        <li><a href="single-task-page.html">Task Page</a></li>
                                        <li><a href="single-company-profile.html">Company Profile</a></li>
                                    </ul>
                                </li>

                                <li><a href="#"><?php echo e(__('For Employers')); ?></a>
                                    <ul class="dropdown-nav">
                                        <li><a href="#"><?php echo e(__('Find a Freelancer')); ?></a>
                                            <ul class="dropdown-nav">
                                                <li><a href="freelancers-grid-layout-full-page.html">Full Page Grid</a></li>
                                                <li><a href="freelancers-grid-layout.html">Grid Layout</a></li>
                                                <li><a href="freelancers-list-layout-1.html">List Layout 1</a></li>
                                                <li><a href="freelancers-list-layout-2.html">List Layout 2</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="single-freelancer-profile.html">Freelancer Profile</a></li>
                                        <li><a href="dashboard-post-a-job.html">Post a Job</a></li>
                                        <li><a href="dashboard-post-a-task.html">Post a Task</a></li>
                                    </ul>
                                </li>

                                <li><a href="#">Dashboard</a>
                                    <ul class="dropdown-nav">
                                        <li><a href="dashboard.html">Dashboard</a></li>
                                        <li><a href="dashboard-messages.html">Messages</a></li>
                                        <li><a href="dashboard-bookmarks.html">Bookmarks</a></li>
                                        <li><a href="dashboard-reviews.html">Reviews</a></li>
                                        <li><a href="dashboard-manage-jobs.html">Jobs</a>
                                            <ul class="dropdown-nav">
                                                <li><a href="dashboard-manage-jobs.html">Manage Jobs</a></li>
                                                <li><a href="dashboard-manage-candidates.html">Manage Candidates</a></li>
                                                <li><a href="dashboard-post-a-job.html">Post a Job</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="dashboard-manage-tasks.html">Tasks</a>
                                            <ul class="dropdown-nav">
                                                <li><a href="dashboard-manage-tasks.html">Manage Tasks</a></li>
                                                <li><a href="dashboard-manage-bidders.html">Manage Bidders</a></li>
                                                <li><a href="dashboard-my-active-bids.html">My Active Bids</a></li>
                                                <li><a href="dashboard-post-a-task.html">Post a Task</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="dashboard-settings.html">Settings</a></li>
                                    </ul>
                                </li>

                                <li><a href="#" class="current">Pages</a>
                                    <ul class="dropdown-nav">
                                        <li><a href="pages-blog.html">Blog</a></li>
                                        <li><a href="pages-pricing-plans.html">Pricing Plans</a></li>
                                        <li><a href="pages-checkout-page.html">Checkout Page</a></li>
                                        <li><a href="pages-invoice-template.html">Invoice Template</a></li>
                                        <li><a href="pages-user-interface-elements.html">User Interface Elements</a></li>
                                        <li><a href="pages-icons-cheatsheet.html">Icons Cheatsheet</a></li>
                                        <li><a href="pages-login.html">Login & Register</a></li>
                                        <li><a href="pages-404.html">404 Page</a></li>
                                        <li><a href="pages-contact.html">Contact</a></li>
                                    </ul>
                                </li>

                                <li>
                                    <a href="#" class="current"><?php echo e(__('Language')); ?></a>
                                    <ul class="dropdown-nav">
                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                                <?php echo e($properties['native']); ?>

                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                            </ul>
                        </nav>
                        <div class="clearfix"></div>
                        <!-- Main Navigation / End -->

                    </div>
                    <!-- Left Side Content / End -->


                    <!-- Right Side Content / End -->
                    <div class="right-side">

                        <?php if(auth()->guard()->check()): ?>
                        <?php if (isset($component)) { $__componentOriginaldf46cd1e63cc820303864e0be9d4e3f3cf84f060 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NotificationMenu::class, []); ?>
<?php $component->withName('notification-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldf46cd1e63cc820303864e0be9d4e3f3cf84f060)): ?>
<?php $component = $__componentOriginaldf46cd1e63cc820303864e0be9d4e3f3cf84f060; ?>
<?php unset($__componentOriginaldf46cd1e63cc820303864e0be9d4e3f3cf84f060); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php endif; ?>

                        <!-- User Menu -->
                        <div class="header-widget">

                            <!-- Messages -->
                            <div class="header-notifications user-menu">
                                <div class="header-notifications-trigger">
                                    <a href="#">
                                        <div class="user-avatar status-online"><img src="<?php echo e(asset('assets/front/images/user-avatar-small-01.jpg')); ?>" alt=""></div>
                                    </a>
                                </div>

                                <!-- Dropdown -->
                                <?php if(auth()->guard()->check()): ?>
                                <div class="header-notifications-dropdown">

                                    <!-- User Status -->
                                    <div class="user-status">

                                        <!-- User Name / Avatar -->
                                        <div class="user-details">
                                            <div class="user-avatar status-online"><img src="<?php echo e(asset('assets/front/images/user-avatar-small-01.jpg')); ?>" alt=""></div>
                                            <div class="user-name">
                                                <?php echo e(Auth::user()->name); ?> <span>Freelancer</span>
                                            </div>
                                        </div>

                                        <!-- User Status Switcher -->
                                        <div class="status-switch" id="snackbar-user-status">
                                            <label class="user-online current-status">Online</label>
                                            <label class="user-invisible">Invisible</label>
                                            <!-- Status Indicator -->
                                            <span class="status-indicator" aria-hidden="true"></span>
                                        </div>
                                    </div>

                                    <ul class="user-menu-small-nav">
                                        <li><a href="dashboard.html"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
                                        <li><a href="dashboard-settings.html"><i class="icon-material-outline-settings"></i> Settings</a></li>
                                        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout').submit();"><i class="icon-material-outline-power-settings-new"></i> Logout</a></li>
                                    </ul>
                                    <form action="<?php echo e(route('logout')); ?>" method="post" style="display: none;" id="logout">
                                        <?php echo csrf_field(); ?>
                                    </form>

                                </div>
                                <?php endif; ?>
                            </div>

                        </div>
                        <!-- User Menu / End -->

                        <!-- Mobile Navigation Button -->
                        <span class="mmenu-trigger">
                            <button class="hamburger hamburger--collapse" type="button">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </span>

                    </div>
                    <!-- Right Side Content / End -->

                </div>
            </div>
            <!-- Header / End -->

        </header>
        <div class="clearfix"></div>
        <!-- Header Container / End -->

        <?php echo e($slot); ?>


        <!-- Footer
================================================== -->
        <div id="footer">

            <!-- Footer Top Section -->
            <div class="footer-top-section">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">

                            <!-- Footer Rows Container -->
                            <div class="footer-rows-container">

                                <!-- Left Side -->
                                <div class="footer-rows-left">
                                    <div class="footer-row">
                                        <div class="footer-row-inner footer-logo">
                                            <img src="<?php echo e(asset('assets/front/images/logo2.png')); ?>" alt="">
                                        </div>
                                    </div>
                                </div>

                                <!-- Right Side -->
                                <div class="footer-rows-right">

                                    <!-- Social Icons -->
                                    <div class="footer-row">
                                        <div class="footer-row-inner">
                                            <ul class="footer-social-links">
                                                <li>
                                                    <a href="#" title="Facebook" data-tippy-placement="bottom" data-tippy-theme="light">
                                                        <i class="icon-brand-facebook-f"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" title="Twitter" data-tippy-placement="bottom" data-tippy-theme="light">
                                                        <i class="icon-brand-twitter"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" title="Google Plus" data-tippy-placement="bottom" data-tippy-theme="light">
                                                        <i class="icon-brand-google-plus-g"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" title="LinkedIn" data-tippy-placement="bottom" data-tippy-theme="light">
                                                        <i class="icon-brand-linkedin-in"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>

                                    <!-- Language Switcher -->
                                    <div class="footer-row">
                                        <div class="footer-row-inner">
                                            <select class="selectpicker language-switcher" data-selected-text-format="count" data-size="5">
                                                <option selected>English</option>
                                                <option>Français</option>
                                                <option>Español</option>
                                                <option>Deutsch</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Footer Rows Container / End -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Top Section / End -->

            <!-- Footer Middle Section -->
            <div class="footer-middle-section">
                <div class="container">
                    <div class="row">

                        <!-- Links -->
                        <div class="col-xl-2 col-lg-2 col-md-3">
                            <div class="footer-links">
                                <h3>For Candidates</h3>
                                <ul>
                                    <li><a href="#"><span>Browse Jobs</span></a></li>
                                    <li><a href="#"><span>Add Resume</span></a></li>
                                    <li><a href="#"><span>Job Alerts</span></a></li>
                                    <li><a href="#"><span>My Bookmarks</span></a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Links -->
                        <div class="col-xl-2 col-lg-2 col-md-3">
                            <div class="footer-links">
                                <h3>For Employers</h3>
                                <ul>
                                    <li><a href="#"><span>Browse Candidates</span></a></li>
                                    <li><a href="#"><span>Post a Job</span></a></li>
                                    <li><a href="#"><span>Post a Task</span></a></li>
                                    <li><a href="#"><span>Plans & Pricing</span></a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Links -->
                        <div class="col-xl-2 col-lg-2 col-md-3">
                            <div class="footer-links">
                                <h3>Helpful Links</h3>
                                <ul>
                                    <li><a href="#"><span>Contact</span></a></li>
                                    <li><a href="#"><span>Privacy Policy</span></a></li>
                                    <li><a href="#"><span>Terms of Use</span></a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Links -->
                        <div class="col-xl-2 col-lg-2 col-md-3">
                            <div class="footer-links">
                                <h3>Account</h3>
                                <ul>
                                    <li><a href="#"><span>Log In</span></a></li>
                                    <li><a href="#"><span>My Account</span></a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Newsletter -->
                        <div class="col-xl-4 col-lg-4 col-md-12">
                            <h3><i class="icon-feather-mail"></i> Sign Up For a Newsletter</h3>
                            <p>Weekly breaking news, analysis and cutting edge advices on job searching.</p>
                            <form action="#" method="get" class="newsletter">
                                <input type="text" name="fname" placeholder="Enter your email address">
                                <button type="submit"><i class="icon-feather-arrow-right"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Middle Section / End -->

            <!-- Footer Copyrights -->
            <div class="footer-bottom-section">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            © 2018 <strong>Hireo</strong>. All Rights Reserved.
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Copyrights / End -->

        </div>
        <!-- Footer / End -->

    </div>
    <!-- Wrapper / End -->

    <!-- Scripts
================================================== -->
    <script src="<?php echo e(asset('assets/front/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/jquery-migrate-3.0.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/mmenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/tippy.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/bootstrap-slider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/snackbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/clipboard.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/custom.js')); ?>"></script>

    <script>
        const userId = "<?php echo e(Auth::id()); ?>";
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
    <script>
        // Snackbar for user status switcher
        $('#snackbar-user-status label').click(function() {
            Snackbar.show({
                text: 'Your status has been changed!',
                pos: 'bottom-center',
                showAction: false,
                actionText: "Dismiss",
                duration: 3000,
                textColor: '#fff',
                backgroundColor: '#383838'
            });
        });
    </script>

</body>

</html><?php /**PATH D:\www\elancer\resources\views/layouts/front.blade.php ENDPATH**/ ?>